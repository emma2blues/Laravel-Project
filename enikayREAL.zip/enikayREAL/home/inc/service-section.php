<section class="ftco-section pt-0">
		<div class="container-fluid px-md-4">
			<div class="row justify-content-center mb-5 pb-0" style="background-color: #011121; margin-bottom: 0px;">
				<div class="col-md-8 text-center heading-section ftco-animate pb-0">
					<br>
					<h2 class="mb-4" style="color: #ffc107;">Our Services</h2>
				</div>
			</div>
			<div class="row pt-0" style="background-color: #011121; margin-top: 0px;">
				<div class="col-md-3">
					<div class="services-wrap">
						<div class="img" style="background-image: url(images/daily-savings.png);"></div>
						<div class="text">
							<i>
							<h2 style="color: #ffc107; text-align: justify;"> - Daily Savings Plan</h2>
							</i>
							<!-- <p>Instant Deposit</p> -->
						</div>
					</div>
				</div>
				<div class="col-md-3">
					<div class="services-wrap">
						<div class="img" style="background-image: url(images/invest-plan.png);"></div>
						<div class="text">
							<i>
							<h2 style="color: #ffc107; text-align: justify;"> - Investment Plan</h2>
							</i>
							<!-- <p>Instant Deposit</p> -->
						</div>
					</div>
				</div>
				<div class="col-md-3">
					<div class="services-wrap">
						<div class="img" style="background-image: url(images/education.png);"></div>
						<div class="text">
							<i>
							<h2 style="color: #ffc107; text-align: justify;"> - Education Target Plan</h2>
							</i>
							<!-- <p>Instant Deposit</p> -->
						</div>
					</div>
				</div>
				<div class="col-md-3">
					<div class="services-wrap">
						<div class="img" style="background-image: url(images/target.png);"></div>
						<div class="text">
							<i>
							<h2 style="color: #ffc107; text-align: justify;"> - Target Plan</h2>
							</i>
							<!-- <p>Instant Deposit</p> -->
						</div>
					</div>
				</div>
				<div class="col-md-3">
					<div class="services-wrap">
						<div class="img" style="background-image: url(images/tourism.png);"></div>
						<div class="text">
							<i>
							<h2 style="color: #ffc107; text-align: justify;"> - Tourist Target Plan</h2>
							</i>
							<!-- <p>Instant Deposit</p> -->
						</div>
					</div>
				</div>

				<div class="col-md-3">
					<div class="services-wrap">
						<div class="img" style="background-image: url(images/property.png);"></div>
						<div class="text">
							<i>
							<h2 style="color: #ffc107; text-align: justify;"> - Property Purchase Plan</h2>
							</i>
							<!-- <p>Instant Deposit</p> -->
						</div>
					</div>
				</div>
				
				<div class="col-md-3">
					<div class="services-wrap">
						<div class="img" style="background-image: url(images/group.png);"></div>
						<div class="text">
							<i>
							<h2 style="color: #ffc107; text-align: justify;"> - Group Savings Plan</h2>
							</i>
							<!-- <p>Instant Deposit</p> -->
						</div>
					</div>
				</div>
				<div class="col-md-3">
					<div class="services-wrap">
						<div class="img" style="background-image: url(images/lock-up.png);"></div>
						<div class="text">
							<i>
							<h2 style="color: #ffc107; text-align: justify;"> - Lock Up Fund and Earn Plan</h2>
							</i>
							<!-- <p>Instant Deposit</p> -->
						</div>
					</div>
				</div>
				<div class="col-md-3">
					<div class="services-wrap">
						<div class="img" style="background-image: url(images/food.png);"></div>
						<div class="text">
							<i>
							<h2 style="color: #ffc107; text-align: justify;"> - Food Stuff Plan</h2>
							</i>
							<!-- <p>Instant Deposit</p> -->
						</div>
					</div>
				</div>
			</div>

			<!-- <div style="background-color: #011121">
				<section class="customer-logos slider">
				   	<div class="slide"><img src="images/client/bitcoin.png"></div>
				      <div class="slide"><img src="images/client/perfectmoney.png"></div>
				      <div class="slide"><img src="images/client/ethereum.png"></div>
				      <div class="slide"><img src="images/client/bitcoincash.png"></div>
				      <div class="slide"><img src="images/client/dash.png"></div>
				      <div class="slide"><img src="images/client/dodgecoin.png"></div>
				      <div class="slide"><img src="images/client/litecoin.png"></div>
				      <div class="slide"><img src="images/client/payeer.png"></div>
				</section>
				<br><br>
			</div> -->


		</div>
	</section>