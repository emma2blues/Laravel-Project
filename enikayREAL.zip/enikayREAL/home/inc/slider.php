<section class="hero-wrap js-fullheight" style="background-image: url('images/slider/slider1.jpg');" data-stellar-background-ratio="0.5">
		<div class="overlay"></div>
		<div class="container">
			<div class="row no-gutters slider-text js-fullheight align-items-center justify-content-center" data-scrollax-parent="true">
				<div class="col-lg-9 ftco-animate text-center">
					<div class="mt-5">
						<h1 class="mb-4">Grow your capital with Enikay Fintech</h1>
						<p class="mb-4" style="color: white; font-size: 20px;"><b>Professional Trading on Investments Plans, Daily Savings, Educational Plans, Tourist Target Plans, Property Target Plans and lots more... Secure the future today.</b></p>
						<p><a href="https://enikayfintech.com.ng/login" class="btn btn-primary">Login</a> <a href="https://enikayfintech.com.ng/register" class="btn btn-white">Register</a></p>
					</div>
				</div>
			</div>
		</div>
	</section>