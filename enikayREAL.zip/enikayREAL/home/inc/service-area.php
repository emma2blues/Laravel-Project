<section class="ftco-section ftco-no-pt ftco-no-pb ftco-services-2 bg-primary">
		<div class="container">
			<div class="row d-flex">
				<div class="col-md-7 py-5">
					<div class="py-lg-5">
						<div class="row justify-content-center pb-5">
							<div class="col-md-12 heading-section ftco-animate">
								<h2 class="mb-3">Why Choose Enikay Fintech?</h2>
							</div>
						</div>
						<div class="row">
							<div class="col-md-12 col-lg-6 d-flex align-self-stretch ftco-animate">
								<div class="media block-6 services d-flex">
									<div class="icon justify-content-center align-items-center d-flex"><span class="flaticon-customer-service"></span></div>
									<div class="media-body pl-4">
										<h3 class="heading mb-3">24/7 Customer Service</h3>
										<p>We provide the most experienced customer support help desk to see through every problem that may occur at any given time.</p>
									</div>
								</div>      
							</div>
							<div class="col-md-12 col-lg-6 d-flex align-self-stretch ftco-animate">
								<div class="media block-6 services d-flex">
									<div class="icon justify-content-center align-items-center d-flex"><i class="fa fa-reply-all" style="font-size: 30px; color: white;" aria-hidden="true"></i></div>
									<div class="media-body pl-4">
										<h3 class="heading mb-3">Prompt Delivery</h3>
										<p>Our Instant and secure investment payments make us one of the most favorite companies for investors. Affordable minimum amount for Investment Plans, Daily Savings is ₦500 and for Investment Plans is ₦3000.</p>
									</div>
								</div>      
							</div>
							<div class="col-md-12 col-lg-6 d-flex align-self-stretch ftco-animate">
								<div class="media block-6 services d-flex">
									<div class="icon justify-content-center align-items-center d-flex"><i class="fa fa-globe" style="font-size: 30px; color: white;" aria-hidden="true"></i></div>
									<div class="media-body pl-4">
										<h3 class="heading mb-3">Reliable Services</h3>
										<p>Transparency means confidence is critical in investments. Look your investments reported in real time.</p>
									</div>
								</div>      
							</div>
							<div class="col-md-12 col-lg-6 d-flex align-self-stretch ftco-animate">
								<div class="media block-6 services d-flex">
									<div class="icon justify-content-center align-items-center d-flex"><i class="fa fa-lock" style="font-size: 30px; color: white;" aria-hidden="true"></i></div>
									<div class="media-body pl-4">
										<h3 class="heading mb-3">Maximum Security</h3>
										<p>We use one of the most experienced, professional and trusted DDoS protection, with high level of security.</p>
									</div>
								</div>      
							</div>
						</div>
					</div>
				</div>
				<div class="col-md-5 d-flex">
					<div class="appointment-wrap p-4 p-lg-5 d-flex align-items-center">
						<div class="overlay"></div>
						<form action="#" class="appointment-form ftco-animate">
							<h3>Contact Us Now</h3>
							<div class="">
								<div class="form-group">
									<input type="text" name="name" class="form-control" placeholder="Full Name">
								</div>
								<div class="form-group">
									<input type="text" name="email" class="form-control" placeholder="Email">
								</div>
								<div class="form-group">
									<input type="text" name="phone" class="form-control" placeholder="Phone">
								</div>
							</div>
							<!-- <div class="">
								<div class="form-group">
									<div class="form-field">
										<div class="select-wrap">
											<div class="icon"><span class="fa fa-chevron-down"></span></div>
											<select name="" id="" class="form-control">
												<option value="">Select Your Services</option>
												<option value="">Bitcoin</option>
												<option value="">Etherum</option>
												<option value="">Payeer</option>
												<option value="">Perfect Money</option>
												<option value="">Other Services</option>
											</select>
										</div>
									</div>
								</div>
							</div> -->
							<div class="">
								<div class="form-group">
									<textarea name="" id="" cols="30" rows="4" class="form-control" placeholder="Message"></textarea>
								</div>
								<div class="form-group">
									<input type="submit" value="Contact Us" class="btn btn-primary py-3 px-4">
								</div>
							</div>
						</form>
					</div>
				</div>
			</div>
		</div>
	</section>