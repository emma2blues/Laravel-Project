<section class="ftco-intro img" style="background-image: url(images/bg3.jpg);">
		<div class="overlay"></div>
		<div class="container">
			<div class="row justify-content-center">
				<div class="col-md-4 text-center">
					<h3 style="color: white; text-align: justify;">About Enikay Fintech</h3>
					<p style="text-align: justify;">Enikay Fintech is a real opportunity to save and earn. Nowadays investment plans and strategies has been one of the main payment instruments and survival plan in our country, which can be used online. Enikayfintech.com.ng has been using this kind of digital payment and investment method for quite a while to help it's client grow their capital and also to gain and raise profit.</p>
					<p class="mb-0" style="text-align: left;"><a href="register.php" class="btn btn-primary px-4 py-3">REGISTER AN ACCOUNT</a></p>
				</div>
				<div class="col-md-3 text-center">
					<h4 style="color: white; text-align: justify;">Referral commission</h4>
					<p style="text-align: justify;">We offer 10% referral bonus for each new members you invite to our investment platform. After he/she makes or complete a deposit, you receive a referral commission.</p>
					<p class="mb-0" style="text-align: left;"><a href="register.php" class="btn btn-primary px-4 py-3">REGISTER AN ACCOUNT</a></p>
				</div>
				<div class="col-md-2 text-center">
					<h3 style="color: white; text-align: justify;">How To Start</h3>
					<h4 style="color: white; text-align: justify;"> <b>Create account</b> </h4>
					<p style="text-align: justify;"> Click on REGISTER and fill in all the data in the registration form to open an account with Enikay Fintech</p>

					<p class="mb-0" style="text-align: left;"><a href="register.php" class="btn btn-primary px-4 py-3">REGISTER AN ACCOUNT</a></p>
				</div>
				<div class="col-md-3 text-center">
					<h4 style="color: white; text-align: justify;">Deposit & Withdrawal</h4>
					<p style="text-align: justify;"><b>- Make your deposit</b><br>
					After login click on make deposit choose deposit method.<br>
					<b>- Withdraw your profit</b><br>
					Daily interest will enter into your account balance automatically which you can withdraw anytime.</p>
					<p class="mb-0" style="text-align: left;"><a href="register.php" class="btn btn-primary px-4 py-3">REGISTER AN ACCOUNT</a></p>
				</div>
			</div>
		</div>
	</section>