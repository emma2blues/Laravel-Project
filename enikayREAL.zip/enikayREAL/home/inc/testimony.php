<section class="ftco-section testimony-section img" style="background-image: url(images/bg_1.jpg);">
		<div class="overlay"></div>
		<div class="container">
			<div class="row justify-content-center mb-5 pb-3">
				<div class="col-md-7 text-center heading-section heading-section-white ftco-animate">
					<span class="subheading">Read Testimonials</span>
					<h2 class="mb-4">Our Happy Customer Says</h2>
				</div>
			</div>
			<div class="row ftco-animate justify-content-center">
				<div class="col-md-12">
					<div class="carousel-testimony owl-carousel ftco-owl">
						<div class="item">
							<div class="testimony-wrap py-4 pb-5 d-flex justify-content-between">
								<div class="user-img" style="background-image: url(images/tst.png)">
									<span class="quote d-flex align-items-center justify-content-center">
										<i class="fa fa-quote-left"></i>
									</span>
								</div>
								<div class="text">
									<p class="mb-4">Enikay Fintech is the best investment platform I've ever come accross. They are reliable and the best in vestment trading platform.</p>
									<p class="name">Taiwo Awopeju</p>
									<span class="position">Active Member</span>
								</div>
							</div>
						</div>
						<div class="item">
							<div class="testimony-wrap py-4 pb-5 d-flex justify-content-between">
								<div class="user-img" style="background-image: url(images/tst.png)">
									<span class="quote d-flex align-items-center justify-content-center">
										<i class="fa fa-quote-left"></i>
									</span>
								</div>
								<div class="text">
									<p class="mb-4">If you are not on Enikay Fintech, you are not anywhere. Trade and invest your money to earn.</p>
									<p class="name">Esther Olalere</p>
									<span class="position">Member</span>
								</div>
							</div>
						</div>
						<div class="item">
							<div class="testimony-wrap py-4 pb-5 d-flex justify-content-between">
								<div class="user-img" style="background-image: url(images/tst.png)">
									<span class="quote d-flex align-items-center justify-content-center">
										<i class="fa fa-quote-left"></i>
									</span>
								</div>
								<div class="text">
									<p class="mb-4">I was able to trade my money with Enikay Fintech on Daily Plans and I have rest and peace of mind. Fast and secure  transactions. I love Enikay Fintech.</p>
									<p class="name">Andrew Johnson</p>
									<span class="position">Member</span>
								</div>
							</div>
						</div>
						<div class="item">
							<div class="testimony-wrap py-4 pb-5 d-flex justify-content-between">
								<div class="user-img" style="background-image: url(images/tst.png)">
									<span class="quote d-flex align-items-center justify-content-center">
										<i class="fa fa-quote-left"></i>
									</span>
								</div>
								<div class="text">
									<p class="mb-4">I love the system, it's so reliable. I was able to do all investment without doubt.</p>
									<p class="name">Bimbo Hassan</p>
									<span class="position">Member</span>
								</div>
							</div>
						</div>
						<div class="item">
							<div class="testimony-wrap py-4 pb-5 d-flex justify-content-between">
								<div class="user-img" style="background-image: url(images/tst.png)">
									<span class="quote d-flex align-items-center justify-content-center">
										<i class="fa fa-quote-left"></i>
									</span>
								</div>
								<div class="text">
									<p class="mb-4">Investment trading at ease. No cash delay, the system is cool for me so far.</p>
									<p class="name">John Phillips</p>
									<span class="position">Member</span>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>