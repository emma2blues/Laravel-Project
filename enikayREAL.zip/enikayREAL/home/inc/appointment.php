<section class="ftco-intro img" style="background-image: url(images/bg3.jpg);">
		<div class="overlay"></div>
		<div class="container">
			<div class="row justify-content-center">
				<div class="col-md-12 text-center">
					<h2>We Are Equipo A Heavy Equipment Renting Company</h2>
					<p>We can manage your dream building A small river named Duden flows by their place</p>
					<p class="mb-0"><a href="#" class="btn btn-primary px-4 py-3">Make An Appointment</a></p>
				</div>
			</div>
		</div>
	</section>