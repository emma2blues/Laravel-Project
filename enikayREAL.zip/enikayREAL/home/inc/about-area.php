<section class="ftco-section ftco-counter ftco-no-pt ftco-no-pb" id="about-section">
		<div class="container">
			<div class="row">
				<div class="col-md-6 d-flex align-items-stretch">
					<div class="about-wrap img w-100" style="background-image: url(images/invest.png);">
					</div>
				</div>
				<div class="col-md-6 py-5 pl-md-5">
					<div class="row justify-content-center mb-4 pt-md-4">
						<div class="col-md-12 heading-section ftco-animate">
							<span class="subheading">Welcome to EnikayFintech</span>
							<h2 class="mb-4">Welcome to Enikay Fintech Trading</h2>
							<p style="color: black;">Enikay Fintech is registered in Ibadan, Nigeria. Our company was formed to utilize advanced savings and investment technology in order to help our clients grow their capital the easy and trusted way. Become a member of our side to start growing your funds everyday.</p>
						</div>
					</div>
					<div class="row">
						<div class="col-md-6 d-flex justify-content-center counter-wrap ftco-animate">
							<div class="block-18">
								<div class="text">
									<strong class="number" data-number="6">0</strong>
									<span>Years of Experienced</span>
								</div>
							</div>
						</div>
						<div class="col-md-6 d-flex justify-content-center counter-wrap ftco-animate">
							<div class="block-18">
								<div class="text">
									<strong class="number" data-number="300">0</strong>
									<span>Customers Served</span>
								</div>
							</div>
						</div>
						<div class="col-md-6 d-flex justify-content-center counter-wrap ftco-animate">
							<div class="block-18">
								<div class="text">
									<strong class="number" data-number="7300">0</strong>
									<span>Successful Transactions</span>
								</div>
							</div>
						</div>
						<div class="col-md-6 d-flex justify-content-center counter-wrap ftco-animate">
							<div class="block-18">
								<div class="text">
									<strong class="number" data-number="21">0</strong>
									<span>Number of Staffs</span>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>