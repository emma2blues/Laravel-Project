<?php $pageTitle='Home'; ?> 
    <?php include('inc/header.php'); ?>
	
	<?php include('inc/slider.php'); ?>

	<?php include('inc/service-area.php'); ?>

	<?php include('inc/about-area.php'); ?>	

	<?php include('inc/arrange.php'); ?>

	<!-- <?php include('inc/appointment.php'); ?> -->	

	<?php include('inc/service-section.php'); ?>	

	<?php include('inc/testimony.php'); ?>	

	<?php include('inc/footer.php'); ?>