<?php 

session_start();

if (!isset($_SESSION['username'])) {
    header("Location: ../login.php");
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Home - Dashboard</title>
 <link rel="apple-touch-icon" sizes="76x76" href="img/apple-icon.png">
  <link rel="icon" type="image/png" href="img/favicon.png">
  <!--     Fonts and icons     -->
  <link href="https://fonts.googleapis.com/css?family=Poppins:200,300,400,600,700,800" rel="stylesheet" />
  <link href="https://use.fontawesome.com/releases/v5.0.6/css/all.css" rel="stylesheet">
  <!-- Nucleo Icons -->
  <link href="css/nucleo-icons.css" rel="stylesheet" />
  <!-- CSS Files -->
  <link href="css/black-dashboard.css?v=1.0.0" rel="stylesheet" />
  <!-- CSS Just for demo purpose, don't include it in your project -->
  <link href="demo/demo.css" rel="stylesheet" />
   
</head>
<body>
  <div class="wrapper">
      <div class="sidebar">
      
          <div class="sidebar-wrapper">
            <div class="logo">
              <!-- <a href="javascript:void(0)" class="simple-text logo-mini">
                ENIKAY
              </a> -->
              <a href="javascript:void(0)" class="simple-text logo-normal">
                ENIKAY FINTECH
              </a>
            </div>
            <ul class="nav">
              <li class="active ">
                <a href="index">
                  <i class="tim-icons icon-chart-pie-36"></i>
                  <p>Dashboard</p>
                </a>
              </li>
              <li>
            <a href="createdeposit.php">
              <i class="tim-icons icon-pin"></i>
              <p>Create Deposit</p>
            </a>
          </li>
          <li>
            <a href="withdraw.php">
              <i class="tim-icons icon-bell-55"></i>
              <p>Withdraw Money</p>
            </a>
          </li>
          <li>
            <a href="deposit-history.php">
              <i class="tim-icons icon-single-02"></i>
              <p>Deposit History</p>
            </a>
          </li>
          <li>
            <a href="withdrawal-history.php">
              <i class="tim-icons icon-puzzle-10"></i>
              <p>Withdrawal History</p>
            </a>
          </li>
          <!-- <li>
            <a href="referrals.php">
              <i class="tim-icons icon-align-center"></i>
              <p>Referral Bonuses</p>
            </a>
          </li> -->
          <li>
            <a href="account.php">
              <i class="tim-icons icon-world"></i>
              <p>Account/Profile Settings</p>
            </a>
          </li>
          <!-- <li>
            <a href="support.php">
              <i class="tim-icons icon-support-17"></i>
              <p>Support</p>
            </a>
          </li> -->
          <li class="">
            <a href="https://enikayfintech.com.ng/logout">
              <i class="tim-icons icon-alert-circle-exc"></i>
              <p>Logout</p>
            </a>
          </li>
            </ul>
          </div>
      </div>


   <div class="main-panel">
      <!-- Navbar -->
      <nav class="navbar navbar-expand-lg navbar-absolute navbar-transparent">
        <div class="container-fluid">
          <div class="navbar-wrapper">
            <div class="navbar-toggle d-inline">
              <button type="button" value="MENU" class="navbar-toggler">
                <span class="navbar-toggler-bar bar1"></span>
                <span class="navbar-toggler-bar bar2"></span>
                <span class="navbar-toggler-bar bar3"></span>
                <br>
                <span style="color: white;" class=""><b>MENU</b></span>
              </button>
            </div>
            <a class="navbar-brand" href="javascript:void(0)">Dashboard</a>
          </div>
          <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navigation" aria-expanded="false" aria-label="Toggle navigation" value="MENU">
            <span class="navbar-toggler-bar navbar-kebab"></span>
            <span class="navbar-toggler-bar navbar-kebab"></span>
            <span class="navbar-toggler-bar navbar-kebab"></span>
          </button> 
          <div class="collapse navbar-collapse" id="navigation">
            <ul class="navbar-nav ml-auto">
              <!-- <li class="search-bar input-group">
                <button class="btn btn-link" id="search-button" data-toggle="modal" data-target="#searchModal"><i class="tim-icons icon-zoom-split" ></i>
                  <span class="d-lg-none d-md-block">Search</span>
                </button>
              </li> -->
              <li class="dropdown nav-item">
                <!-- <a href="#" class="dropdown-toggle nav-link" data-toggle="dropdown">
                  <div class="photo">
                    <img src="../assets/img/anime3.png" alt="Profile Photo">
                  </div>
                  <b class="caret d-none d-lg-block d-xl-block"></b>
                  <p class="d-lg-none">
                    Log out
                  </p>
                </a> -->
                <ul class="dropdown-menu dropdown-navbar">
                  <!-- <li class="nav-link"><a href="javascript:void(0)" class="nav-item dropdown-item">Profile</a></li>
                  <li class="nav-link"><a href="javascript:void(0)" class="nav-item dropdown-item">Settings</a></li>
                  <li class="dropdown-divider"></li>
                  <li class="nav-link"><a href="/logout" class="nav-item dropdown-item">Log out</a></li> -->
                </ul>
              </li>
              <li class="separator d-lg-none"></li>
            </ul>
          </div>
        </div>
      </nav>
   
      <div class="modal modal-search fade" id="searchModal" tabindex="-1" role="dialog" aria-labelledby="searchModal" aria-hidden="true">
          <div class="modal-dialog" role="document">
            <div class="modal-content">
              <div class="modal-header">
                <input type="text" class="form-control" id="inlineFormInputGroup" placeholder="SEARCH">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <i class="tim-icons icon-simple-remove"></i>
                </button>
              </div>
            </div>
          </div>
      </div>
      <!-- End Navbar -->
      
      <div class="content">

          <?php
                error_reporting(E_ALL); 
                ini_set('display_errors', 1);
                $servername = "localhost:3306";
                $username = "enikayfi_ssl";
                $password = "+v8GCpMz183Xt+";
                $db_name = "enikayfi_ssl";

                // Create connection
                $conn = new mysqli($servername, $username, $password, $db_name);
                // Check connection
                if ($conn->connect_error){
                  die("Connection failed: " . $conn->connect_error);
                } 
                
                $id = ''; 
                if( isset( $_SESSION['id'])) {
                    $id = $_SESSION['id']; 
                } 
                $id = mysqli_real_escape_string($conn,$id);
                $query = "SELECT * FROM `register` WHERE `username`='" . $_SESSION['username']. "'";
                $result = mysqli_query($conn,$query);

                while($row = mysqli_fetch_array($result)) {
                echo '<h3>Welcome, <br> '. $row['fullname'] .' ('. $row['username'] .')</h3>';
              }
            ?>

        <div class="row">
          <div class="col-lg-4">
            <div class="card card-chart">
              <div class="card-header">

                <?php 
                        $username=$_SESSION['username'];
                        $query = mysqli_query($conn, "SELECT SUM(d_amount) AS d_total FROM `deposit` WHERE `username`='" . $_SESSION['username']. "'") or die(mysqli_error());
                        $fetch = mysqli_fetch_array($query);
                        {
                      ?>
                <h5 class="card-category">Total Deposit</h5>
                <h3 class="card-title"><i class="tim-icons icon-bell-55 text-primary"></i> ₦ <?php echo number_format($fetch['d_total'])?></h3>
                <?php } ?>

              </div>
              <!-- <div class="card-body">
                <div class="chart-area">
                  <canvas id="chartLinePurple"></canvas>
                </div>
              </div> -->
            </div>
          </div>
          <div class="col-lg-4">
            <div class="card card-chart">
              <div class="card-header">

                 <?php 
                        $username=$_SESSION['username'];
                        $query = mysqli_query($conn, "SELECT SUM(w_amount) AS w_total FROM `withdrawal` WHERE `username`='" . $_SESSION['username']. "'") or die(mysqli_error());
                        $fetch = mysqli_fetch_array($query);
                        {
                      ?>
                <h5 class="card-category">Total Withdrawal</h5>
                <h3 class="card-title"><i class="tim-icons icon-delivery-fast text-info"></i> ₦ <?php echo number_format($fetch['w_total'])?></h3>
                <?php } ?>

              </div>
              <!-- <div class="card-body">
                <div class="chart-area">
                  <canvas id="CountryChart"></canvas>
                </div>
              </div> -->
            </div>
          </div>
          <div class="col-lg-4">
            <div class="card card-chart">
              <div class="card-header">


                <!-- <h5 class="card-category">Balance</h5>
                <h3 class="card-title"><i class="tim-icons icon-send text-success"></i> 0</h3>
                 -->

              </div>
              <!-- <div class="card-body">
                <div class="chart-area">
                  <canvas id="chartLineGreen"></canvas>
                </div>
              </div> -->
            </div>
          </div>

          <h3 style="text-align: center; margin-left: 15px; margin-right: 15px;"><b>PLEASE NOTE: OUR SYSTEM RUNS MANUALLY FOR NOW. SO PLEASE ALWAYS CHAT THE WHATSAPP NUMBER BELOW FOR WITHDRAWAL REQUEST</b></h3>
    
        </div>

        <center>
          <a href=""><h4 style="text-align: center; margin-left: 15px; margin-right: 15px;"><b>CLICK HERE TO CHAT US ON WHATSAPP</b></h4></a>
          </center>

        <div class="row">
          <div class="col-lg-12 col-md-12">
            <div class="card ">
              <div class="card-header">
                <h4 class="card-title">My Account</h4>
              </div>
              <div class="card-body">
                <div class="table-responsive">
                  <table class="table tablesorter " id="">
                    <thead class=" text-primary">
                      <tr>
                        <th>
                        
                        </th>
                        <th>
                          
                        </th>
                      </tr>
                    </thead>
                    <tbody>
                      <?php
                        require_once 'config.php';
                        $username=$_SESSION['username'];
                        $query = mysqli_query($conn, "SELECT * FROM `profile` WHERE `username`='" . $_SESSION['username']. "'") or die(mysqli_error());
                        while($fetch = mysqli_fetch_array($query)){
                      ?>

                      <tr>
                        <td>
                          User
                        </td>
                        <td>
                        <?php echo $fetch['3'];?>
                        </td>
                      </tr>
                      <tr>
                        <td>
                          Registration Date
                        </td>
                        <td>
                        <?php echo $fetch['9'];?>
                        </td>
                      </tr>
                      <tr>
                        <td>
                          Phone Number
                        </td>
                        <td>
                        <?php echo $fetch['4'];?>
                        </td>
                      </tr>
                      <tr>
                        <td>
                          Date of Birth
                        </td>
                        <td>
                        <?php echo $fetch['5'];?>
                        </td>
                      </tr>
                      <tr>
                        <td>
                          Bank Name
                        </td>
                        <td><?php echo $fetch['6'];?></td>
                      </tr>
                      <tr>
                        <td>
                        Account Name
                        </td>
                        <td><?php echo $fetch['7'];?></td>
                      </tr>
                      <tr>
                        <td>
                        Account Number
                        </td>
                        <td><?php echo $fetch['8'];?></td>
                      </tr>

                    </tbody>
                  </table>

                  <?php } ?>



                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
  

      <?php include('inc/footer-index.php'); ?>