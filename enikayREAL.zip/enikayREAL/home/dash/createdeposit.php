<?php include('inc/header.php'); ?>
   
      <div class="content">
        <div class="row">
          <div class="col-md-12">
            <div class="card ">
              <div class="card-header">
                <h4 class="card-title">Create Deposit</h4>
              </div>
              <div class="card-body">

              <form method="POST" action="deposit-mail.php" enctype="multipart/form-data">
                
              <div class="form-group" style="color:white;">
              <h4>Means of payment</h4>
              <input checked type="radio" value="Bank Transfer" id="Means" name="paymentmode" /> Bank Transfer<br/> <br/>

              <hr style="width: 100%; background-color: yellow;">
              <p><i>Please make your payment to the account number below</i></p>
              <br>
              <h4>Account Number: 0735017175</h4>
              <h4>Account Name: Samson Micheal Bayo</h4
                >
              <h4>Bank Name: Access Bank</h4>

              <hr style="width: 100%; background-color: yellow;">
              </div>

              <div class="form-group" style="color:white;">
              
              <input type="text" name="name" placeholder="Enter Your Full Name" style="width: 295px;" required="" /><br/> <br/>
              <input type="text" name="username" placeholder="Enter Your Username" style="width: 295px;" required="" /><br/> <br/>
              <input type="email" name="email" placeholder="Enter Your Email" style="width: 295px;" required="" /><br/> <br/>

              <hr style="width: 100%; background-color: yellow;">
              </div>


              <!-- <div class="form-group" style="color:white;">
              <h4>Choose Plan(s)</h4>
              <input type="radio" value="Daily Savings Plan" name="dailysavings" /> Daily Savings Plan<br/> <br/>
              <input type="radio" value="Investment Plan" name="investment" /> Investment Plan<br/> <br/>
              <input type="radio" value="Education Target Plan" name="education" /> Education Target Plan<br/> <br/>
              <input type="radio" value="Target Plan" name="target" /> Target Plan<br/> <br/>
              <input type="radio" value="Tourist Target Plan" name="tourist" /> Tourist Target Plan<br/> <br/>
              <input type="radio" value="Property Purchase Plan" name="property" /> Property Purchase Plan<br/> <br/>
              <input type="radio" value="Group Savings Plan" name="group" /> Group Savings Plan<br/> <br/>
              <input type="radio" value="Lock Up Fund and Earn Plan" name="lockup" /> Lock Up Fund and Earn Plan<br/> <br/>
              <input type="radio" value="Food Stuff Plan" name="food" /> Food Stuff Plan<br/> <br/>


              <hr style="width: 100%; background-color: yellow;">
              </div> -->

              <h3>Select Your Plan</h3>

              <div class="form-group">
              <label style="color:white; font-size:18px;"><b>Plan</b></label><br>
              <select name="plan" style="width: 295px;"  required="" />
                <option value="">-- Select Plan --</option>
                <option value="Daily Savings Plan">Daily Savings Plan</option>
                <option value="Investment Plan">Investment Plan</option>
                <option value="Education Target Plan">Education Target Plan</option>
                <option value="Target Plan">Target Plan</option>
                <option value="Tourist Target Plan">Tourist Target Plan</option>
                <option value="Property Purchase Plan">Property Purchase Plan</option>
                <option value="Group Savings Plan">Group Savings Plan</option>
                <option value="Lock Up Fund and Earn Plan">Lock Up Fund and Earn Plan</option>
                <option value="Food Stuff Plan">Food Stuff Plan</option>
              </select>
              </div>
              
              
              <br><br>
              <div class="form-group">
              <label style="color:white; font-size:18px;">Amount to Deposit: <b>₦ </b></label><br>
              <input placeholder="Amount in ₦" style="width: 295px;" id="" pattern="^[\d,]+$" type="text" data-val="true" data-val-number="The field Amount must be a number." data-val-required="The Amount field is required." id="Amount" name="d_amount" value="0" required="" />

              <br><br>
              <hr style="width: 100%; background-color: white;">
              <p style="color: yellow;"><i>After clicking on the <b>'Deposit Now' button</b>, you'll be redirected to upload your proof of payment. Make sure you upload correct proof of payment or else your accout gets blocked immediately.</i></p>
              <p></p>
              </div>

              
              <!-- <div class="">
                
              <label style="color:white; font-size:18px;"><b>Upload Proof of Payment</b></label>
              <br>
              <input type="file" name="attachment" style="background-color: white;" required="" />
              </div> -->
              <br><br>

              <div class="form-group">
              <input type="submit" value="Deposit Now" name="submit" class="btn btn-success"/>
              </div>

              <input name="__RequestVerificationToken" type="hidden" value="CfDJ8HcYZw8hyk1LuD5zb4MhC77ggEdYXUMkyKjWzVOQfrohvTQO2jX1AoVv7zo4mjY9zYrgPdkX5fYG5z3r9LOLrrjU5Kqmb1U5P8CSRFpvlc1hVrzOJgqrDDCKMvHyZhwxoAGDSjpoKZamu6vS95dH6dSD3qDkuYCUpc8OkVAPBN2LxVMX8M5otjLAXkAPEDtwJA" /></form>






              </div>
            </div>
          </div>
        </div>
      </div>

<?php include('inc/footer.php'); ?>