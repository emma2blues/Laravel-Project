<?php 
	return [ 
	    'ak' => env('VARIABLE_KEY',''),
	    'reg_url' => '',	    
	];